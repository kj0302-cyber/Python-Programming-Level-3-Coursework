length =100
width=100
area= length * width
print (area)