password=input("please enter a password ")

if password == "apple":
    print("password accepted")
else:
    print("access denide")

login = input("please log in ")

if login == "khadijah":
    print("login accepted")
else:
    print("incorrect log in name")


