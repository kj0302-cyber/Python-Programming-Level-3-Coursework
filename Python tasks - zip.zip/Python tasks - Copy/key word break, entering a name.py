while True:
    name = input ("please type your name")

    if name == "your name":

        break

print ("thank you!")
# this makes the code break and stop looping