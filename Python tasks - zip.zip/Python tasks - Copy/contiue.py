while True:
    print("Who are you?")
    name = input()
    if name != "joe":
        continue
    print("Hello Joe what is the password? (It is a fish)")
    password = input()
    if password == "swordfish":
        break
print("Access granted")
#countiue makes the loop continue until you give the correct answer and the swordfish is the sentinel value since that stops the loop and makes the sequence end