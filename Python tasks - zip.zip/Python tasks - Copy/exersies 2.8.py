grade= int(input("please enter a grade please"))

if grade <= 90:
    print("A")
elif grade <= 80 and 90:
    print("B")
elif grade <= 70 and 80:
    print("C")
elif grade <= 60 and 70:
    print("D")
elif grade <= 50 and 60:
    print("F")