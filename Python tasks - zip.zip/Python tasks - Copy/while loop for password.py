PASSWORD = "super_password123"
password_entered = ""
while password_entered != PASSWORD:
    password_entered = input("Enter a password:")
# the while is used to make a loop. the ! means if the password is wrong