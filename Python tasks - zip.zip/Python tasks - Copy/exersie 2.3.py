length = float(input('please enter a length'))
width = float(input('please enter a width'))
area= length * width
print ('the area is',area)