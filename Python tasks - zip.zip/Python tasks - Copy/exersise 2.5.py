password=input("please enter a password")

if password == "apple":
    print("password accepted")
else:
    print("access denide")
