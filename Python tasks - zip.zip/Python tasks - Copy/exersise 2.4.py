loanamount= float(input("please enter a loan amount"))
monthlyintrestrate= float(input("please enter a monthly intrest rate"))
monthlypayment= loanamount * monthlyintrestrate
print ("monthly payment is", monthlypayment)