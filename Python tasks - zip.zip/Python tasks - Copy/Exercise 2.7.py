number_x = int(input("Enter an interger:"))
if number_x % 5 == 0:
    print("HiFive")
if number_x % 2 ==0:
    print("HiEven")